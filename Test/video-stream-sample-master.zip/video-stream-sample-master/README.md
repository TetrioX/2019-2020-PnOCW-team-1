This is a basic sample of how to do video streaming using Node.js and HTML5

# Install

- git clone
- npm install
- npm start
- open browser in `localhost:3000`